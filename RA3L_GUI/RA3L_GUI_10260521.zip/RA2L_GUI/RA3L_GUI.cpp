#include <tchar.h>
#include <Windows.h>
#include "resource.h"

INT_PTR CALLBACK RA2L_Main(HWND hwndDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_INITDIALOG:
		{
			HWND hComBox = GetDlgItem(hwndDlg, START3);
			SendMessage(hComBox, CB_INSERTSTRING, 0, (LPARAM)_T("��������̨ -ui"));
			SendMessage(hComBox, CB_INSERTSTRING, 1, (LPARAM)_T("��������̨+���ڻ� -ui -win"));
			SendMessage(hComBox, CB_INSERTSTRING, 2, (LPARAM)_T("���ܹ��� ra3_tool.exe"));
			SendMessage(hComBox, CB_INSERTSTRING, 3, (LPARAM)_T("�������к��л�ע����޸� ra3_fix.exe"));
			SendMessage(hComBox, CB_INSERTSTRING, 4, (LPARAM)_T("�޸��� RA3Trainer.exe"));
			SendMessage(hComBox, CB_INSERTSTRING, 5, (LPARAM)_T("RA3ReplaysManager.exe"));
		}
		break;

	case WM_COMMAND:
		{
		switch (wParam)
		{
		case IDRA3:
			system("start ra3.exe");
			break;
		case IDRA3WIN:
			system("start ra3.exe -win");
			break;
		case IDRA3EXIT:
			system("taskkill /f /im ra3.exe");
			system("taskkill /f /im ra3_1.12.game");
			break;
		case START3GO:
				{
					TCHAR szText[50] = {0};
					GetDlgItemText(hwndDlg, START3, szText, 50);
					if ( _tcscmp(szText, _T("��������̨ -ui")) == 0 ) {
						system("start ra3.exe -ui");
					}else if ( _tcscmp(szText, _T("��������̨+���ڻ� -ui -win")) == 0 ) {
						system("start ra3.exe -ui -win");
					}
					else if ( _tcscmp(szText, _T("���ܹ��� ra3_tool.exe")) == 0 ) {
						system("start ra3_tool.exe");
					}
					else if ( _tcscmp(szText, _T("�������к��л�ע����޸� ra3_fix.exe")) == 0 ) {
						system("start ra3_fix.exe");
					}
					else if ( _tcscmp(szText, _T("�޸��� RA3Trainer.exe")) == 0 ) {
						system("start RA3Trainer.exe");
					}
					else if ( _tcscmp(szText, _T("RA3ReplaysManager.exe")) == 0 ) {
						system("start RA3ReplaysManager.exe");
					}
				}
				break;
		case IDHELP:
			{
			MessageBox(hwndDlg, _T("* �Ѵ˳�����ں쾯3�ļ�����\n\n* �汾���� 2016.5.21\n* �����ߣ�wcan\n"), _T("����&����"), MB_OK);
			}
			break;
		case IDCLOSE:
			EndDialog(hwndDlg, IDCLOSE);
			break;
		case IDCANCEL:
			EndDialog(hwndDlg, IDCANCEL);
			break;
		}
	default:
			break;
		}
	}
	
	return 0;
}


INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}



int APIENTRY _tWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{
	if (_tcscmp(lpCmdLine, _T("-help")) == 0) {
		DialogBox(hInstance, MAKEINTRESOURCE(IDD_ABOUT), NULL, About);
	}
	else if (_tcscmp(lpCmdLine, _T("-c")) == 0) {
		DialogBox(hInstance, MAKEINTRESOURCE(IDD_ABOUT), NULL, About);
	}
	else {
		DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, RA2L_Main);
	}
	
	
	return 0;
}

